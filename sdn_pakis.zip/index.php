<?php
include "component/header.php";
include "component/navigation.php";
include "component/slider.php";
include "component/pemesanan.php";
include "component/why.php";
include "component/package.php";
include "component/subscribe.php";
?>

<?php include "component/footer.php"; ?>
