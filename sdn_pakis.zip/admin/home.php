<?php
include "component/header.php";
include "component/main-header.php";
include "component/sidebar-left.php";
include "content/$file";
include "component/footer.php";
include "component/main-footer.php";
?>
