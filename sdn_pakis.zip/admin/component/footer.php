<!-- Main Footer -->
<footer class="main-footer">
  <!-- To the right -->
  <div class="pull-right hidden-xs">
    CV Travel Anda
  </div>
  <script>
    	initSample();
  </script>
  <!-- Default to the left -->
  <strong>Copyright &copy; 2016 <a href="#">Travel Anda</a>.</strong> All rights reserved.
</footer>
