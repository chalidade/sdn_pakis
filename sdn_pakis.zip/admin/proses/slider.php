<?php
include "koneksi.php";

$target_dir = "image/slider/";

// $target_file1 = $target_dir . basename($_FILES["file1"]);
// $target_file2 = $target_dir . basename($_FILES["file2"]);
// $target_file3 = $target_dir . basename($_FILES["file3"]);
//
// $uploadOk1 = 1;
// $uploadOk2 = 1;
// $uploadOk3 = 1;
// $imageFileType1 = strtolower(pathinfo($target_file1,PATHINFO_EXTENSION));
// $imageFileType2 = strtolower(pathinfo($target_file2,PATHINFO_EXTENSION));
// $imageFileType3 = strtolower(pathinfo($target_file3,PATHINFO_EXTENSION));
//
// // Check if file already exists
// if (file_exists($target_file1)) {
//     echo "Sorry, file already exists.";
//     $uploadOk1 = 0;
// }
// if (file_exists($target_file2)) {
//     echo "Sorry, file already exists.";
//     $uploadOk2 = 0;
// }
// if (file_exists($target_file3)) {
//     echo "Sorry, file already exists.";
//     $uploadOk3 = 0;
// }
//
// // Check if $uploadOk is set to 0 by an error
// if ($uploadOk3 == 0) {
//     // echo "<script>alert('Sorry, your file was not uploaded.')</script>";
// // if everything is ok, try to upload file
// } else {
//     if (move_uploaded_file($photo["tmp_name"], $target_file2)) {
//         echo "The file ". basename($_FILES["file1"]). " has been uploaded.";
//     } else {
//         echo "<script>alert('Sorry, there was an error uploading your file.')</script>";
//     }
// }
//
// // Check if $uploadOk is set to 0 by an error
// if ($uploadOk2 == 0) {
//     // echo "<script>alert('Sorry, your file was not uploaded.')</script>";
// // if everything is ok, try to upload file
// } else {
//     if (move_uploaded_file($photo["tmp_name"], $target_file3)) {
//         echo "The file ". basename( $_FILES["file3"]). " has been uploaded.";
//     } else {
//         echo "<script>alert('Sorry, there was an error uploading your file.')</script>";
//     }
// }
//
// // Check if $uploadOk is set to 0 by an error
// if ($uploadOk1 == 0) {
//     // echo "<script>alert('Sorry, your file was not uploaded.')</script>";
// // if everything is ok, try to upload file
// } else {
//     if (move_uploaded_file($photo["tmp_name"], $target_file1)) {
//         echo "The file ". basename( $_FILES["file1"]). " has been uploaded.";
//     } else {
//         echo "<script>alert('Sorry, there was an error uploading your file.')</script>";
//     }
// }

// $query = mysqli_query($connect, "UPDATE `$table` SET `photo` = '$target_file' WHERE `$table`.`id` = '$id'");

 ?>
