<?php
include "component/header.php";
include "component/form_payment.php";
include "component/footer.php";
?>
