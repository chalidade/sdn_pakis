<script type="text/javascript">
  alert("Pesanan Anda sedang Diproses");
</script>
