<div class="tour-package" style="text-align:center;margin-top:50px">
  <h5 style="font-weight:800">Berita Sekolah Hari Ini</h5>
  <div class="row" style="margin-top:70px;margin:50px auto;display: inline-block;">
    <div class="col s3" style="width:300px;border-radius:10px;" class="modal-trigger" href="#myModal">
      <div class="package" style="box-shadow: 5px 7px 5px #dcdcdc40;border-radius:10px">
        <div class="fotoPaket" style="height:250px;border-top-left-radius: 10px;border-top-right-radius: 10px;background:url('img/gunung_bromo.png');background-size:cover"></div>
        <div class="deskripsiPaket" style="padding:8px;padding-bottom:20px;">
          <h3 style="font-size:14px;font-weight:800">Kegiatan Upacara Bendera 17 Agustus</h3>
          <p style="font-size:10px">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
        </div>
      </div>
    </div>
    <div class="col s3" style="width:300px;border-radius:10px;" class="modal-trigger" href="#myModal">
      <div class="package" style="box-shadow: 5px 7px 5px #dcdcdc40;border-radius:10px">
        <div class="fotoPaket" style="height:250px;border-top-left-radius: 10px;border-top-right-radius: 10px;background:url('img/gunung_bromo.png');background-size:cover"></div>
        <div class="deskripsiPaket" style="padding:8px;padding-bottom:20px;">
          <h3 style="font-size:14px;font-weight:800">Kegiatan Upacara Bendera 17 Agustus</h3>
          <p style="font-size:10px">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
        </div>
      </div>
    </div>
    <div class="col s3" style="width:300px;border-radius:10px;" class="modal-trigger" href="#myModal">
      <div class="package" style="box-shadow: 5px 7px 5px #dcdcdc40;border-radius:10px">
        <div class="fotoPaket" style="height:250px;border-top-left-radius: 10px;border-top-right-radius: 10px;background:url('img/gunung_bromo.png');background-size:cover"></div>
        <div class="deskripsiPaket" style="padding:8px;padding-bottom:20px;">
          <h3 style="font-size:14px;font-weight:800">Kegiatan Upacara Bendera 17 Agustus</h3>
          <p style="font-size:10px">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
        </div>
      </div>
    </div>
    <div class="col s3" style="width:300px;border-radius:10px;" class="modal-trigger" href="#myModal">
      <div class="package" style="box-shadow: 5px 7px 5px #dcdcdc40;border-radius:10px">
        <div class="fotoPaket" style="height:250px;border-top-left-radius: 10px;border-top-right-radius: 10px;background:url('img/gunung_bromo.png');background-size:cover"></div>
        <div class="deskripsiPaket" style="padding:8px;padding-bottom:20px;">
          <h3 style="font-size:14px;font-weight:800">Kegiatan Upacara Bendera 17 Agustus</h3>
          <p style="font-size:10px">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
        </div>
      </div>
    </div>
  </div>
  <center><a href="package.php" class="btn light-blue lighten-1" style="height: 35px;border-radius:20px;font-size:10px;text-transform:Capitalize;width:140px;margin-top:15px">View All</a></center>
</div>
