<div style="margin-top:600px;height: 550px;z-index:999;background:url('img/lorong_kelas.jpg');background-size:cover">
  <div class="row">
    <div class="col s12" style="background: linear-gradient(90deg, rgba(255,255,255,1) 5%, rgba(246,246,255,0.6) 68%, rgba(0,212,255,0) 100%);">
      <div class="col s6" style="margin-left:-15px;padding: 40px;padding-top:70px;height:550px;">
        <h2 style="font-size:36px;font-weight:800">Kata Pengantar</h2>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
      </div>
    </div>

  </div>
</div>
